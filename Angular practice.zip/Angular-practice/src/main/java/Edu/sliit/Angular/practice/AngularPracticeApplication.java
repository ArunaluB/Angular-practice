package Edu.sliit.Angular.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularPracticeApplication.class, args);
	}

}
